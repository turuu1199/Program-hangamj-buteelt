package com.example.lab3a;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab3aApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab3aApplication.class, args);
	}

}
