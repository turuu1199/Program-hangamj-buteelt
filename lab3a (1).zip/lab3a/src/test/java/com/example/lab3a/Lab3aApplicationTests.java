package com.example.lab3a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab3aApplicationTests {

	@Test
	void contextLoads() {
	}

}
